alter table "public"."task_distribution" rename column "user_id" to "contributor_id";
