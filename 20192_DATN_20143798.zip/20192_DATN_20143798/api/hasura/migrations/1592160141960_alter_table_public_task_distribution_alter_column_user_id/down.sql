alter table "public"."task_distribution" rename column "contributor_id" to "user_id";
