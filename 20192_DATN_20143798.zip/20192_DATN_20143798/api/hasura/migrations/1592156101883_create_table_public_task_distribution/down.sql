DROP TABLE "public"."task_distribution";
