ALTER TABLE "public"."projects" DROP COLUMN "check_dates";
