ALTER TABLE "public"."annotations" DROP COLUMN "created_at";
