ALTER TABLE "public"."task_distribution" DROP COLUMN "is_approved";
