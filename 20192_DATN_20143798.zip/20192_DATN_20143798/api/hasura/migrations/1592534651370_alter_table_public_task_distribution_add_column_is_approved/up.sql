ALTER TABLE "public"."task_distribution" ADD COLUMN "is_approved" boolean NOT NULL DEFAULT false;
