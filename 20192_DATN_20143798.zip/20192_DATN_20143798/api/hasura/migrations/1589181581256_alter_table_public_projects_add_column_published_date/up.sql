ALTER TABLE "public"."projects" ADD COLUMN "published_date" date NULL;
