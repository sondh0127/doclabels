ALTER TABLE "public"."projects" DROP COLUMN "published_date";
