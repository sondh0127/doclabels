ALTER TABLE "public"."projects" ALTER COLUMN "published_date" TYPE timestamptz;
