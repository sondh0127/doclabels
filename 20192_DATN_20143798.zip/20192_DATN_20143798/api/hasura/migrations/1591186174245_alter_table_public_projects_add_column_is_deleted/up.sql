ALTER TABLE "public"."projects" ADD COLUMN "is_deleted" boolean NULL DEFAULT false;
