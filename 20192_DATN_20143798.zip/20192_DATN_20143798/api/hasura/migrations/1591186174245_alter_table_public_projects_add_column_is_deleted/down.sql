ALTER TABLE "public"."projects" DROP COLUMN "is_deleted";
