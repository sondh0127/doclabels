alter table "public"."annotations" drop constraint "annotations_task_id_fkey";
