alter table "public"."annotations" rename column "task_id" to "document_id";
