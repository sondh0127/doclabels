alter table "public"."annotations" rename column "document_id" to "task_id";
