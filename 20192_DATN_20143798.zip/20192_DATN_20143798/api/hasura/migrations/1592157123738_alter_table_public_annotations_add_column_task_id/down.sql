ALTER TABLE "public"."annotations" DROP COLUMN "task_id";
