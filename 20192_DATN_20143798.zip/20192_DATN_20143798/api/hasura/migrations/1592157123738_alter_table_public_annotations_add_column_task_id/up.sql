ALTER TABLE "public"."annotations" ADD COLUMN "task_id" uuid NOT NULL;
