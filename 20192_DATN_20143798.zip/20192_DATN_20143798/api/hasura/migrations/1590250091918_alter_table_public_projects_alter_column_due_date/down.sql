ALTER TABLE "public"."projects" ALTER COLUMN "due_date" TYPE date;
