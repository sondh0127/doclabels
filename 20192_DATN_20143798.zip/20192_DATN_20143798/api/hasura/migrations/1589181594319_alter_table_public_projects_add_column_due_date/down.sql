ALTER TABLE "public"."projects" DROP COLUMN "due_date";
