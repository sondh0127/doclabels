ALTER TABLE "public"."projects" ADD COLUMN "due_date" date NULL;
