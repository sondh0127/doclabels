alter table "public"."project_contributors" drop constraint "project_contributors_project_id_user_id_key";
