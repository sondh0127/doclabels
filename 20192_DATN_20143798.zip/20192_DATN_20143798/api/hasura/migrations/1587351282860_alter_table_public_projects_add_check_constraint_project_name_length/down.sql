alter table "public"."projects" drop constraint "project_name_length";
