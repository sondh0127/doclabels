alter table "public"."documents" drop constraint "documents_project_id_text_key";
