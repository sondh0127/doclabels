import express, { Request, Response, NextFunction } from "express";
// import bodyParser from "body-parser";
// import fetch from "node-fetch";
import cors from "cors";
import fs from "fs";
import { fileUploadArgs, fileOutput } from "./fileUploadTypes";

const app = express();

const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ limit: "10mb" }));

app.use(express.static("public"));

app.post("/hello", async (req, res) => {
  return res.json({
    hello: "world",
  });
});

function fileUploadHandler(args: fileUploadArgs): fileOutput {
  const { base64str, name, type } = args;
  let fileBuffer = Buffer.from(base64str, "base64");
  try {
    fs.writeFileSync("./public/files/" + name, fileBuffer, "base64");
  } catch (e) {
    console.log(`functionfileUploadHandler -> e`, e);
  }

  return {
    file_path: `http://localhost:3001/files/${name}`,
  };
}

const fileUpload = async (req: Request, res: Response, next: NextFunction) => {
  const params: fileUploadArgs = req.body.input;
  const result = fileUploadHandler(params);

  // success
  return res.json(result);
};

app.post("/fileUpload", fileUpload);

app.listen(PORT);
