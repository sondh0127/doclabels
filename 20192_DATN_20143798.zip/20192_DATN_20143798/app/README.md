# README

new table for this
finished = models.BooleanField(default=False)

new table for this
prob = models.FloatField(default=0.0)

new table for this
manual = models.BooleanField(default=False)

Reward for annotations.

@connection(key: "Labels", filter: ["project_id"])
@connection(key: "Documents", filter: ["project_id"])
@connection(key: "DocumentsAnnotation", filter: ["project_id", "user_id"])

vercel secrets add auth0_client_secret 6iwBnnjrDCTl8g3gJxgQ4uh5Np5AZ414UU_sgu3eABPxPOoA_WRNMRr66ceyY14W

vercel secrets add session_cookie_secret GF3qmtZmQQeDJO7YG4koq5lZCt022mlC

chia task moi dua tren nhung task chua hoan thanh(confirm) - not total assign task
