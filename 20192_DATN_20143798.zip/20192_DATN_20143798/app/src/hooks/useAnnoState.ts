import { useRouter } from 'next/router'
import {
  useProjectsByPkQuery,
  useLabelsQuery,
  useDocumentsAnnotationQuery,
} from '@/generated/graphql'
import { useMemo, useEffect } from 'react'
import { arrayToDictObj } from '@/utils/utils'
import { useRecoilValue } from 'recoil'
import { pageNumberState } from '@/contexts/atoms/annotation'

export const useApolloState = () => {
  const router = useRouter()
  const { pid } = router.query

  const { data: projectData, loading: projectLoading } = useProjectsByPkQuery({
    variables: { id: pid },
  })

  const { data: labelData, loading: labelLoading } = useLabelsQuery({
    variables: { project_id: pid },
  })
  const { data: docData, loading: docLoading } = useDocumentsAnnotationQuery({
    variables: { project_id: pid },
  })

  const state = useMemo(() => {
    return {
      currentProject: projectData?.projects_by_pk || null,
      labelList: labelData?.labels || [],
      labelMap: arrayToDictObj(labelData?.labels || [], 'id'),
      docList: docData?.documents || [],
      totalDoc: docData?.documents_aggregate.aggregate?.count || 0,
      // doneDoc:
      //   docData?.documents_aggregate.nodes.filter(
      //     (item) => item.annotations_aggregate.aggregate?.count! > 0,
      //   ).length || 0,
      // taskIds,
      // annoList: [],
      projectLoading,
      labelLoading,
      docLoading,
    }
  }, [
    projectData?.projects_by_pk,
    labelData?.labels,
    docData?.documents,
    docData?.documents_aggregate?.aggregate?.count,
    // docData?.documents_aggregate?.nodes?.filter,
    projectLoading,
    labelLoading,
    docLoading,
  ])

  return state
}

export const useCurrentDoc = () => {
  const { docList } = useApolloState()
  const pageNumber = useRecoilValue(pageNumberState)

  return useMemo(() => docList[pageNumber] || null, [pageNumber, docList])
}

export const useAnnoList = () => {
  // Maybe bug here
  const currentDoc = useCurrentDoc()
  const [queryAnno, { data, loading }] = useAnnotationsLazyQuery()

  useEffect(() => {
    if (currentDoc) {
      queryAnno({
        variables: {
          task_id: currentDoc.id,
        },
      })
    }
  }, [currentDoc])

  const state = useMemo(() => {
    return {
      annoList: data?.annotations || [],
      annoLoading: loading,
    }
  }, [data?.annotations, loading])

  return state
}
