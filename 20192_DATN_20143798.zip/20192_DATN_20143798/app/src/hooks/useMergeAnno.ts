import { useCallback } from 'react'
import { useRecoilValue } from 'recoil'
import {
  currentDocState,
  currentProjectState,
  versionIdState,
  downloadDocState,
  exportFormatState,
  DraftAnnoState,
} from '@/contexts/atoms/annotation'
import {
  TextClassificationAnnotation,
  Seq2seqAnnotation,
  DraftSeq2seqAnnotation,
  DraftTextClassificationAnnotation,
} from '@/types'
import useDraftAnno from './useDraftAnno'
import { saveAs } from 'file-saver'
import { EXPORTED_FORMAT_TYPE } from '@/constants/document'
// @ts-ignore
import json2csv from 'csvjson-json2csv'
import { uniqWith } from 'lodash'

export const useMergeAnno = () => {
  const { presentAnno } = useDraftAnno()
  const currentDoc = useRecoilValue(currentDocState)
  const versionId = useRecoilValue(versionIdState)
  const currentProject = useRecoilValue(currentProjectState)
  const downloadDoc = useRecoilValue(downloadDocState)
  const exportFormat = useRecoilValue(exportFormatState)

  const getMergeAnnoTextClassification = useCallback((annoList: DraftAnnoState) => {
    const annoByLabel = annoList.reduce((prev, curr) => {
      ;(prev[curr.label_id] = prev[curr.label_id] || []).push(
        curr as DraftTextClassificationAnnotation,
      )
      return prev
    }, {} as Record<string, DraftTextClassificationAnnotation[]>)

    const annoByVersion = annoList.reduce((prev, curr) => {
      if (curr.user_id) {
        ;(prev[curr.user_id] = prev[curr.user_id] || []).push(
          curr as DraftTextClassificationAnnotation,
        )
      }
      return prev
    }, {} as Record<string, DraftTextClassificationAnnotation[]>)

    const mergedAnno = Object.entries(annoByLabel)
      .filter(([key, value]) => value.length >= Object.keys(annoByVersion).length / 2)
      .reduce((results, [key, value]) => {
        results[key] = annoByLabel[key]
        return results
      }, {} as Record<string, DraftTextClassificationAnnotation[]>)

    return mergedAnno
  }, [])

  const exportTextClassification = useCallback(() => {
    const exportData = {
      text: currentDoc?.text,
      labels: Object.values(getMergeAnnoTextClassification(presentAnno)).map(
        (item) => item[0].label?.text,
      ),
    }
    let formatedExportData = JSON.stringify(exportData, null, 2)

    if (exportFormat === 'csv') {
      formatedExportData = json2csv({
        ...exportData,
        labels: exportData.labels.join(', '),
      })
    }
    if (exportFormat === 'txt') {
      formatedExportData = json2csv({
        ...exportData,
        labels: exportData.labels.join(', '),
      })
        .split('\n')
        .splice(1)
        .join('\n')
    }

    const blob = new Blob([formatedExportData], {
      type: EXPORTED_FORMAT_TYPE[exportFormat],
    })
    saveAs(blob, `${currentProject?.name}-${currentDoc?.id}-${versionId}.${exportFormat}`)
  }, [getMergeAnnoTextClassification, presentAnno, exportFormat, versionId])

  const exportAllTextClassification = useCallback(() => {
    const exportData = downloadDoc.map((item) => {
      return {
        text: item.text,
        labels: Object.values(getMergeAnnoTextClassification(item.annotations)).map(
          (item) => item[0].label?.text,
        ),
      }
    })
    let formatedExportData = JSON.stringify(exportData, null, 2)
    if (exportFormat === 'csv') {
      formatedExportData = json2csv(
        exportData.map((item) => {
          return {
            ...item,
            labels: item.labels.join(', '),
          }
        }),
      )
    }
    if (exportFormat === 'txt') {
      formatedExportData = json2csv(
        exportData.map((item) => {
          return {
            ...item,
            labels: item.labels.join(', '),
          }
        }),
      )
        .split('\n')
        .splice(1)
        .join('\n')
    }
    const blob = new Blob([formatedExportData], { type: exportFormat })
    saveAs(blob, `${currentProject?.name}-${versionId}.${exportFormat}`)
  }, [downloadDoc, exportFormat, currentProject?.name, versionId, getMergeAnnoTextClassification])

  // Seq2seq
  const getMergeAnnoSeq2seq = useCallback((annoList: DraftAnnoState) => {
    const annoByLabel = annoList.reduce((prev, curr) => {
      ;(prev[curr.label_id] = prev[curr.label_id] || []).push(curr as DraftSeq2seqAnnotation)
      return prev
    }, {} as Record<string, DraftSeq2seqAnnotation[]>)

    const mergedAnno = Object.entries(annoByLabel).reduce((prev, [key, value]) => {
      const uniq = uniqWith(value, (a, b) => {
        if (a.data.type === 'Seq2seqAnnotation' && b.data.type === 'Seq2seqAnnotation') {
          return a.data.text === b.data.text
        }
        return false
      })
      prev[key] = uniq
      return prev
    }, {} as Record<string, DraftSeq2seqAnnotation[]>)

    return mergedAnno
  }, [])

  const exportSeq2seq = useCallback(() => {
    const annoByLabel = Object.values(getMergeAnnoSeq2seq(presentAnno)).reduce((prev, curr) => {
      if (curr[0].label?.text) {
        prev[curr[0].label?.text] = curr.map((item) => item.data.text)
      }
      return prev
    }, {} as Record<string, string[]>)

    const exportData = {
      text: currentDoc?.text,
      ...annoByLabel,
    }
    let formatedExportData = JSON.stringify(exportData, null, 2)

    const annoByLabelText = Object.values(getMergeAnnoSeq2seq(presentAnno)).reduce((prev, curr) => {
      if (curr[0].label?.text) {
        prev[curr[0].label?.text] = curr.map((item) => item.data.text).join(', ')
      }
      return prev
    }, {} as Record<string, string>)
    if (exportFormat === 'csv') {
      formatedExportData = json2csv({
        ...exportData,
        ...annoByLabelText,
      })
    }
    if (exportFormat === 'txt') {
      formatedExportData = json2csv({
        ...exportData,
        ...annoByLabelText,
      })
        .split('\n')
        .splice(1)
        .join('\n')
    }

    const blob = new Blob([formatedExportData], {
      type: EXPORTED_FORMAT_TYPE[exportFormat],
    })
    saveAs(blob, `${currentProject?.name}-${currentDoc?.id}-${versionId}.${exportFormat}`)
  }, [
    getMergeAnnoSeq2seq,
    presentAnno,
    currentDoc?.text,
    currentDoc?.id,
    exportFormat,
    currentProject?.name,
    versionId,
  ])

  const exportAllSeq2seq = useCallback(() => {
    const exportData = downloadDoc.map((item) => {
      const annoByLabel = Object.values(getMergeAnnoSeq2seq(item.annotations)).reduce(
        (prev, curr) => {
          if (curr[0].label?.text) {
            prev[curr[0].label?.text] = curr.map((item) => item.data.text)
          }
          return prev
        },
        {} as Record<string, string[]>,
      )
      return {
        text: item.text,
        ...annoByLabel,
      }
    })
    let formatedExportData = JSON.stringify(exportData, null, 2)

    const exportDataText = downloadDoc.map((item) => {
      const annoByLabel = Object.values(getMergeAnnoSeq2seq(item.annotations)).reduce(
        (prev, curr) => {
          if (curr[0].label?.text) {
            prev[curr[0].label?.text] = curr.map((item) => item.data.text).join(', ')
          }
          return prev
        },
        {} as Record<string, string>,
      )
      return {
        text: item.text,
        ...annoByLabel,
      }
    })

    if (exportFormat === 'csv') {
      formatedExportData = json2csv(exportDataText)
    }
    if (exportFormat === 'txt') {
      formatedExportData = json2csv(exportDataText).split('\n').splice(1).join('\n')
    }
    const blob = new Blob([formatedExportData], { type: exportFormat })
    saveAs(blob, `${currentProject?.name}-${versionId}.${exportFormat}`)
  }, [downloadDoc, exportFormat, currentProject?.name, versionId, getMergeAnnoSeq2seq])

  // Seq2seq

  return {
    mergeAnnoTextClassification: getMergeAnnoTextClassification(presentAnno),
    mergeAnnoSeq2seq: getMergeAnnoSeq2seq(presentAnno),
    exportTextClassification,
    exportAllTextClassification,
    exportSeq2seq,
    exportAllSeq2seq,
  }
}
