import { useState, useEffect, useRef, MutableRefObject } from 'react'
import { sortBy } from 'lodash'
import { Label } from '@/types'

import rangy from 'rangy'
import 'rangy/lib/rangy-textrange'
import 'rangy/lib/rangy-classapplier'
import 'rangy/lib/rangy-highlighter'

// // @ts-ignore
// rangy.init()
// // @ts-ignore
// const highlighter = rangy.createHighlighter()
// // @ts-ignore
// highlighter.addClassApplier(rangy.createClassApplier('highlight'))

interface Offset {
  start: number
  end: number
}
export interface State extends Offset {
  text: string
}

type TDom = HTMLElement | Document

type Arg = TDom | (() => TDom) | null

const initOffset: Offset = {
  start: NaN,
  end: NaN,
}

const initState: State = {
  text: '',
  ...initOffset,
}

const selectionIsEmpty = (selection: Selection) => {
  const position = selection?.anchorNode?.compareDocumentPosition(selection.focusNode!)
  return position === 0 && selection.focusOffset === selection.anchorOffset
}

const selectionIsBackwards = (selection: Selection) => {
  if (selectionIsEmpty(selection)) return false

  const position = selection?.anchorNode?.compareDocumentPosition(selection.focusNode!)

  let backward = false
  if (
    (!position && selection.anchorOffset > selection.focusOffset) ||
    position === Node.DOCUMENT_POSITION_PRECEDING
  )
    backward = true

  return backward
}

function getSafeRanges(dangerous) {
  const a = dangerous.commonAncestorContainer
  // Starts -- Work inward from the start, selecting the largest safe range
  const s = new Array(0),
    rs = new Array(0)
  if (dangerous.startContainer != a)
    for (let i = dangerous.startContainer; i != a; i = i.parentNode) s.push(i)
  if (0 < s.length)
    for (let i = 0; i < s.length; i++) {
      const xs = document.createRange()
      if (i) {
        xs.setStartAfter(s[i - 1])
        xs.setEndAfter(s[i].lastChild)
      } else {
        xs.setStart(s[i], dangerous.startOffset)
        xs.setEndAfter(s[i].nodeType == Node.TEXT_NODE ? s[i] : s[i].lastChild)
      }
      rs.push(xs)
    }

  // Ends -- basically the same code reversed
  const e = new Array(0),
    re = new Array(0)
  if (dangerous.endContainer != a)
    for (let i = dangerous.endContainer; i != a; i = i.parentNode) e.push(i)
  if (0 < e.length)
    for (let i = 0; i < e.length; i++) {
      const xe = document.createRange()
      if (i) {
        xe.setStartBefore(e[i].firstChild)
        xe.setEndBefore(e[i - 1])
      } else {
        xe.setStartBefore(e[i].nodeType == Node.TEXT_NODE ? e[i] : e[i].firstChild)
        xe.setEnd(e[i], dangerous.endOffset)
      }
      re.unshift(xe)
    }

  // Middle -- the uncaptured middle
  let xm
  if (0 < s.length && 0 < e.length) {
    xm = document.createRange()
    xm.setStartAfter(s[s.length - 1])
    xm.setEndBefore(e[e.length - 1])
  } else {
    return [dangerous]
  }

  // Concat
  rs.push(xm)
  const response = rs.concat(re)

  // Send to Console
  return response
}

function highlightRange(range) {
  const newNode = document.createElement('div')
  newNode.setAttribute('style', 'background-color: yellow; display: inline;')
  range.surroundContents(newNode)
}

function highlightSelection() {
  const userSelection = window.getSelection().getRangeAt(0)

  try {
    highlightRange(userSelection)
  } catch (err) {
    console.log(`highlightSelection -> err`)
  }
  // const safeRanges = getSafeRanges(userSelection)
  // console.log(`highlightSelection -> safeRanges`, safeRanges.length)
  // for (let i = 0; i < safeRanges.length; i++) {
  //   if (safeRanges[i]) {
  //     highlightRange(safeRanges[i])
  //   }
  // }
}

const rangySelection = (container: Node) => {
  const sel = rangy.getSelection()
  if (sel.rangeCount > 0) {
    const range = sel.getRangeAt(0)
    console.log(`rangySelection -> range`, range)
    if (range && container) {
      const offset = range.toCharacterRange(container)
      console.log(`rangySelection -> offset`, offset)
    }
  }
  // Highlight
  // highlighter.highlightSelection('highlight')
  // const selTxt = rangy.getSelection()
  // console.log(`selTxt: ${selTxt}`)
  // rangy.getSelection().removeAllRanges()
}

function useTextSelection<T extends TDom = TDom>(): [State, MutableRefObject<T>]
function useTextSelection<T extends TDom = TDom>(arg: Arg): [State]
function useTextSelection<T extends TDom = TDom>(
  ...args: [Arg] | []
): [State, MutableRefObject<T>?] {
  const hasPassedInArg = args.length === 1
  const arg = useRef(args[0])
  const ref = useRef<T>()
  const [state, setState] = useState(initState)

  const stateRef = useRef(state)
  stateRef.current = state

  useEffect(() => {
    const passedInArg = typeof arg.current === 'function' ? arg.current() : arg.current
    const target = hasPassedInArg ? passedInArg : ref.current

    if (!target) {
      return () => null
    }

    const mouseupHandler = () => {
      let selObj = null
      let text = ''
      if (!window.getSelection) return
      selObj = window.getSelection()
      text = selObj ? selObj.toString() : ''

      if (selObj && text) {
        if (ref.current) {
          rangySelection(ref.current)
        }
        let start = parseInt(selObj.anchorNode?.parentElement?.dataset.i!, 10)
        let end = parseInt(selObj.focusNode?.parentElement?.dataset.i!, 10)

        if (selectionIsBackwards(selObj)) {
          ;[start, end] = [end, start]
        }
        end += 1
        setState({ ...state, text, start, end })
      }
    }

    const mousedownHandler = () => {
      if (!window.getSelection) return
      if (stateRef.current.text) {
        setState({ ...initState })
      }
      const selObj = window.getSelection()
      if (!selObj) return
      selObj.removeAllRanges()
    }

    target.addEventListener('mouseup', mouseupHandler)

    document.addEventListener('mousedown', mousedownHandler)

    return () => {
      target.removeEventListener('mouseup', mouseupHandler)
      document.removeEventListener('mousedown', mousedownHandler)
    }
  }, [ref.current, typeof arg.current === 'function' ? undefined : arg.current])

  if (hasPassedInArg) {
    return [state]
  }

  return [state, ref as MutableRefObject<T>]
}

export default useTextSelection

export interface MarkedToken {
  start_offset: number
  end_offset: number
  tokens: string[]
  label_text: string
  id: string
  label: Label
}

export interface TokenSpan {
  mark?: MarkedToken
  content: string
  i?: number
}

export const splitTokensWithOffsets = (text: string[], offsets: MarkedToken[]) => {
  let lastEnd = 0
  const splits: TokenSpan[] = []

  for (const offset of sortBy(offsets, (o) => o.start_offset)) {
    const { start_offset, end_offset } = offset
    if (lastEnd < start_offset) {
      for (let i = lastEnd; i < start_offset; i++) {
        splits.push({
          i,
          content: text[i],
        })
      }
    }
    splits.push({
      mark: offset,
      content: text.slice(start_offset, end_offset).join(' '),
    })
    lastEnd = end_offset
  }

  for (let i = lastEnd; i < text.length; i++) {
    splits.push({
      i,
      content: text[i],
    })
  }

  return splits
}
