import { atom, selector } from 'recoil'
import { Label, RoleTypes, Annotation, Project, DocumentAnnotation, DraftAnnotation } from '@/types'
import { Toast } from '@elastic/eui/src/components/toast/global_toast_list'
import {
  Role_Types_Enum,
  TaskDistributionFragment,
  DocumentsDownloadQuery,
} from '@/generated/graphql'

export const selectedLabelState = atom<Label | undefined>({
  key: 'selectedLabelState',
  default: undefined,
})

export const selectedAnnotationState = atom<DraftAnnotation | null>({
  key: 'selectedAnnotationState',
  default: null,
})

export const projectRoleState = atom<RoleTypes>({
  key: 'projectRoleState',
  default: Role_Types_Enum.Annotator,
})

export const versionIdState = atom<string>({
  key: 'versionIdState',
  default: 'all',
})

export const isApprovedState = atom<boolean>({
  key: 'isApprovedState',
  default: false,
})

export const exportFormatState = atom<'json' | 'csv' | 'txt'>({
  key: 'exportFormatState',
  default: 'json',
})

export const currentProjectState = atom<Project | null>({
  key: 'currentProjectState',
  default: null,
})

export const docState = atom<DocumentAnnotation[]>({
  key: 'docState',
  default: [],
})

export const downloadDocState = atom<DocumentsDownloadQuery['documents']>({
  key: 'downloadDocState',
  default: [],
})

export const labelState = atom<Label[]>({
  key: 'labelState',
  default: [],
})

export const pageNumberState = atom({
  key: 'pageNumberState',
  default: 0,
})

export const currentDocState = selector<DocumentAnnotation | null>({
  key: 'currentDocState',
  get: ({ get }) => {
    const pageNumber = get(pageNumberState)
    const docs = get(docState)

    return docs[pageNumber]
  },
})

export const currentTaskState = selector<TaskDistributionFragment | undefined>({
  key: 'currentTaskState',
  get: ({ get }) => {
    const currentDoc = get(currentDocState)

    return currentDoc?.task_distributions[0]
  },
})

export const annoListState = atom<Annotation[]>({
  key: 'annoListState',
  default: [],
})

// isDisabled: boolean,
export type DraftAnnoState = DraftAnnotation[]

export const presentAnnoState = atom<DraftAnnoState>({
  key: 'presentAnnoState',
  default: [],
})

export const pastAnnoState = atom<DraftAnnoState[]>({
  key: 'pastAnnoState',
  default: [],
})

export const futureAnnoState = atom<DraftAnnoState[]>({
  key: 'futureAnnoState',
  default: [],
})

export const globalAnnoToastListState = atom<Toast[]>({
  key: 'globalAnnoToastListState',
  default: [],
})
