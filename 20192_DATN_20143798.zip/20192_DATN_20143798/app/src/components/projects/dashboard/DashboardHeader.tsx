import { PROJECT_TYPE_ICON, PROJECT_TYPE_TAG } from '@/constants'
import { Project } from '@/types'
import {
  EuiFlexGroup,
  EuiFlexItem,
  EuiPageContentHeader,
  EuiPageContentHeaderSection,
  EuiTitle,
  EuiFlexGrid,
  EuiText,
} from '@elastic/eui'
import React from 'react'
import styles from './dashboard.module.scss'

export interface Statistics {
  contributors: number
  tasks: number
  labels: number
  visits: number
}

interface DashboardHeaderProps {
  currentProject: Project
  statistics: Statistics
}

const DashboardHeader: React.FC<DashboardHeaderProps> = ({ currentProject, statistics }) => {
  return (
    <EuiPageContentHeader>
      <EuiPageContentHeaderSection>
        <EuiFlexGroup alignItems="center">
          <EuiFlexItem grow={false} className={styles.projectIcon}>
            {PROJECT_TYPE_ICON[currentProject.project_type]}
          </EuiFlexItem>
          <EuiFlexItem>
            <EuiTitle size="l">
              <h1>{currentProject.name}</h1>
            </EuiTitle>
            <div>{PROJECT_TYPE_TAG[currentProject.project_type]}</div>
          </EuiFlexItem>
        </EuiFlexGroup>
      </EuiPageContentHeaderSection>

      <EuiPageContentHeaderSection>
        {currentProject.is_public && (
          <EuiFlexGrid>
            {/* <Statistic title="Contributors" value={statistics.contributors} />
            <SpaceDivider />
            <Statistic title="Tasks" value={statistics.tasks} />
            <SpaceDivider />
            <Statistic title="Labels" value={statistics.labels} />
            <SpaceDivider />
            <Statistic title="Visits" value={statistics.visits} /> */}
          </EuiFlexGrid>
        )}
        {!currentProject.is_public && <EuiText>Draft</EuiText>}
      </EuiPageContentHeaderSection>
    </EuiPageContentHeader>
  )
}

export default DashboardHeader
