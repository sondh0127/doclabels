import { Project } from '@/types'
import React, { useContext } from 'react'
import ContributionCard from './components/ContributionCard'
import { ProjectDashboardQuery } from '@/generated/graphql'
import { EuiFlexGroup, EuiFlexItem, EuiCard, EuiText } from '@elastic/eui'
// import { Chart, Partition } from '@elastic/charts'
// import { EUI_CHARTS_THEME_DARK, EUI_CHARTS_THEME_LIGHT } from '@elastic/eui/dist/eui_charts_theme'
import { getTheme } from '@/lib/eui/theme'
import Link from 'next/link'

interface PublishedContentProps {
  currentProject: Project
  data?: ProjectDashboardQuery
  loading: boolean
  percent: number
}

const PublishedContent: React.FC<PublishedContentProps> = ({
  currentProject,
  data,
  loading,
  percent,
}) => {
  /**
   * Setup theme based on current light/dark theme
   */
  // const isDarkTheme = getTheme().includes('dark')
  // const euiChartTheme = isDarkTheme ? EUI_CHARTS_THEME_DARK : EUI_CHARTS_THEME_LIGHT
  // const euiPartitionConfig = euiChartTheme.partition

  return (
    <>
      <Link href="/annotation/[pid]" as={`/annotation/${currentProject.id}`}>
        <a> Go to Annotation</a>
      </Link>
      <EuiFlexGroup>
        <EuiFlexItem>
          <ContributionCard data={data} loading={loading} />
        </EuiFlexItem>
        <EuiFlexItem>
          <EuiFlexGroup>
            <EuiText size="s">Project progress</EuiText>
            {/* <Chart size={{ height: 200 }}>
              <Partition
                id="progress"
                data={[
                  {
                    browser: 'Approving',
                    percent: 61.72,
                  },
                  {
                    browser: 'Annotating',
                    percent: 100 - 61.72,
                  },
                ]}
                valueAccessor={(d) => Number(d.percent)}
                layers={[
                  {
                    groupByRollup: (d) => d.browser,
                    shape: {
                      fillColor: (d) => euiChartTheme.theme.colors!.vizColors![d.sortIndex],
                    },
                  },
                ]}
                config={{
                  ...euiPartitionConfig,
                  emptySizeRatio: 0.4,
                  clockwiseSectors: false,
                }}
              />
            </Chart> */}
          </EuiFlexGroup>
        </EuiFlexItem>
      </EuiFlexGroup>
    </>
  )
}

export default PublishedContent
