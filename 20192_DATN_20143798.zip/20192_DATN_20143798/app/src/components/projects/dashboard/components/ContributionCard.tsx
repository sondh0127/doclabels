import React, { useState, useMemo } from 'react'
import { ProjectDashboardQuery } from '@/generated/graphql'
import { EuiFlexItem, EuiFlexGroup, EuiCard, EuiTab } from '@elastic/eui'

interface ContributionCardProps {
  loading?: boolean
  data?: ProjectDashboardQuery
}

const ContributionCard: React.FC<ContributionCardProps> = ({ loading, data }) => {
  const [key, setKey] = useState('documents')

  const tabList = [
    {
      key: 'documents',
      tab: 'Documents',
    },
    {
      key: 'labels',
      tab: 'Labels',
    },
    {
      key: 'contributors',
      tab: 'Contributors',
    },
  ]

  const labelData = useMemo(
    () =>
      data?.labels_aggregate.nodes.map((l) => ({
        Label: l.text,
        Annotation: l.annotations_aggregate.aggregate?.count,
      })),
    [data],
  )

  const docData = useMemo(
    () =>
      data?.documents_aggregate.nodes.map((d) => ({
        Document: d.text.slice(0, 7),
        Annotation: d.annotations_aggregate.aggregate?.count,
      })),
    [data],
  )

  const contributorData: {
    [field: string]: string | number | number[] | null | undefined
  }[] = useMemo(
    () =>
      data?.project_contributors_aggregate.nodes.map((d) => ({
        Contributor: d.user.name,
        Annotation: d.id,
      })) || [],
    [data],
  )

  const contentList: Record<string, React.ReactNode> = useMemo(
    () => ({
      documents: (
        <EuiFlexGroup>
          <EuiFlexItem>
            {/* <BarChart
              height={300}
              forceFit
              data={docData}
              xField="Annotation"
              yField="Document"
              label={{
                visible: true,
                position: 'middle',
              }}
              barSize={27}
            /> */}
          </EuiFlexItem>
        </EuiFlexGroup>
      ),
      labels: (
        <EuiFlexGroup>
          <EuiFlexItem>
            {/* <BarChart
              height={300}
              forceFit
              data={labelData}
              xField="Annotation"
              yField="Label"
              label={{
                visible: true,
                position: 'middle',
              }}
              barSize={27}
            /> */}
          </EuiFlexItem>
        </EuiFlexGroup>
      ),
      contributors: (
        <EuiFlexGroup>
          <EuiFlexItem>
            {/* <BarChart
              height={300}
              forceFit
              data={contributorData}
              xField="Annotation"
              yField="Contributor"
              label={{
                visible: true,
                position: 'middle',
              }}
              barSize={27}
            /> */}
          </EuiFlexItem>
        </EuiFlexGroup>
      ),
    }),
    [],
  )

  return (
    <EuiTab
    // loading={loading}
    // bordered={false}
    // tabList={tabList}
    // activeTabKey={key}
    // onTabChange={setKey}
    // bodyStyle={{ padding: 0 }}
    >
      {contentList[key]}
      {/* Docs progress  remaining/total */}
    </EuiTab>
  )
}

export default ContributionCard
