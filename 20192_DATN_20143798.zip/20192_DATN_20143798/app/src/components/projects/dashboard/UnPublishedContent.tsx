import React, { useMemo } from 'react'
import { Project } from '@/types'
import Link from 'next/link'
import PublishingForm from './components/PublishingForm'
import { Statistics } from './DashboardHeader'
import {
  EuiCallOut,
  EuiFlexGroup,
  EuiFlexItem,
  EuiText,
  EuiSpacer,
  EuiPanel,
  EuiTextColor,
  EuiLink,
} from '@elastic/eui'
import { useSetRecoilState } from 'recoil'
import { currentProjectPageState } from '@/contexts/atoms/currentProject'

interface UnPublishedContentProps {
  currentProject: Project
  showTaskAlert: boolean
  showLabelAlert: boolean
  statistics: Statistics
}

const UnPublishedContent: React.FC<UnPublishedContentProps> = ({
  currentProject,
  showLabelAlert,
  showTaskAlert,
  statistics,
}) => {
  const showGuildlineAlert = useMemo(() => !currentProject.guideline, [currentProject])
  const setCurrentProjectPage = useSetRecoilState(currentProjectPageState)

  return (
    <EuiFlexGroup direction="column">
      {showTaskAlert && (
        <EuiFlexItem>
          <EuiCallOut title="Add a document to project" color="warning" iconType="help">
            {/* <Link href="/projects/[pid]/document" as={`/projects/${currentProject?.id}/document`}> */}
            <EuiLink onClick={() => setCurrentProjectPage('document')}>Go to Documents</EuiLink>
            {/* </Link> */}
          </EuiCallOut>
        </EuiFlexItem>
      )}

      {showLabelAlert && (
        <EuiFlexItem>
          <EuiCallOut title="Define the label for tasks" color="warning" iconType="help">
            {/* <Link href="/projects/[pid]/label" as={`/projects/${currentProject?.id}/label`}> */}
            <EuiLink onClick={() => setCurrentProjectPage('label')}>Go to Labels</EuiLink>
            {/* </Link> */}
          </EuiCallOut>
        </EuiFlexItem>
      )}
      {showGuildlineAlert && (
        <EuiFlexItem>
          <EuiCallOut
            title="Add guide line for user for better annotation process"
            color="warning"
            iconType="help"
          >
            {/* <Link href="/projects/[pid]/guide" as={`/projects/${currentProject?.id}/guide`}> */}
            <EuiLink onClick={() => setCurrentProjectPage('guide')}>Go to Guideline</EuiLink>

            {/* </Link> */}
          </EuiCallOut>
        </EuiFlexItem>
      )}
      {!showLabelAlert && !showTaskAlert && (
        <EuiFlexItem>
          <EuiCallOut title="Create check point before publish" color="warning" iconType="help" />
          <EuiSpacer size="m" />
          <EuiFlexGroup>
            <EuiFlexItem grow={false}>
              <EuiPanel>
                <EuiText size="xs">
                  <h3>Project summary</h3>
                </EuiText>
                <EuiSpacer size="s" />
                <EuiText>
                  <span>
                    Number of task:{' '}
                    <EuiTextColor color="secondary">{statistics.tasks}</EuiTextColor>
                  </span>
                </EuiText>
                <EuiSpacer size="s" />
                <EuiText>
                  <span>
                    Number of label:{' '}
                    <EuiTextColor color="secondary">{statistics.labels}</EuiTextColor>
                  </span>
                </EuiText>
              </EuiPanel>
            </EuiFlexItem>
            <EuiFlexItem>
              <PublishingForm statistics={statistics} />
            </EuiFlexItem>
          </EuiFlexGroup>
        </EuiFlexItem>
      )}
    </EuiFlexGroup>
  )
}

export default UnPublishedContent
