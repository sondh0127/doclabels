import { PROJECT_TYPE_ICON } from '@/constants'
import { Project } from '@/types'
import { EuiButton, EuiCard, EuiCode, EuiFlexGroup, EuiFlexItem, EuiText } from '@elastic/eui'
import moment from 'moment'
import React from 'react'
import ProjectBadge from '../project-badge'

export interface Statistics {
  tasks: number
  done: number
  contributors: number
}

interface ProjectFieldSetProps {
  item: Project
  extra?: string
  onClickExtra: () => void
  statistics: Statistics
}

const ProjectFieldSet: React.FC<ProjectFieldSetProps> = ({
  item,
  extra,
  onClickExtra,
  statistics,
}) => {
  return (
    <EuiCard
      layout="vertical"
      icon={<span>{PROJECT_TYPE_ICON[item.project_type]}</span>}
      title={`${item.name}`}
      description={
        <span>
          <ProjectBadge projectType={item.project_type} />
        </span>
      }
      footer={
        <EuiFlexGroup>
          <EuiFlexItem>
            <EuiFlexGroup justifyContent="center" gutterSize="l" alignItems="center">
              <EuiCode>
                {statistics.tasks} {Number(statistics.tasks) === 1 ? ' task' : ' tasks'}
              </EuiCode>
              <EuiCode>{statistics.done} done</EuiCode>
              <EuiCode>{statistics.contributors} contributors</EuiCode>
            </EuiFlexGroup>
          </EuiFlexItem>
          <EuiFlexItem grow={false} onClick={onClickExtra}>
            <EuiButton>{extra}</EuiButton>
          </EuiFlexItem>
        </EuiFlexGroup>
      }
      onClick={() => {}}
    >
      <EuiFlexGroup direction="column" gutterSize="s">
        <EuiFlexItem>
          <EuiText size="xs">Update {moment(item.created_at).fromNow()}</EuiText>
        </EuiFlexItem>
        <EuiFlexItem>
          <EuiCode>
            <EuiText size="s" color="secondary">
              {item.description}
            </EuiText>
          </EuiCode>
        </EuiFlexItem>
      </EuiFlexGroup>
    </EuiCard>
  )
}

export default ProjectFieldSet
