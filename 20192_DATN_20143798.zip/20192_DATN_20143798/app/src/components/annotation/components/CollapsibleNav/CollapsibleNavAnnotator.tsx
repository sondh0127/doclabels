import React, { Fragment, useState, useMemo } from 'react'
import { useRecoilState, useRecoilValue } from 'recoil'
import { pageNumberState, docState } from '@/contexts/atoms/annotation'
import { DocumentAnnotation } from '@/types'
import {
  EuiListGroupItemProps,
  EuiText,
  EuiFlexItem,
  EuiCollapsibleNavGroup,
  EuiProgress,
  EuiFilterGroup,
  EuiFilterButton,
  EuiSpacer,
  EuiListGroup,
} from '@elastic/eui'

interface CollapsibleNavAnnotatorProps {}

type FilterType = 'all' | 'active' | 'completed'

const CollapsibleNavAnnotator: React.FC<CollapsibleNavAnnotatorProps> = () => {
  const [pageNumber, setPageNumber] = useRecoilState(pageNumberState)

  const [filter, setFilter] = useState<FilterType>('all')
  const docList = useRecoilValue(docState)

  const isConfirmed = (item: DocumentAnnotation) => {
    return item.task_distributions.some((item) => item.is_confirmed)
  }

  // let filteredTask = docList
  // if (filter === 'active') {
  //   filteredTask = docList.filter((item) => !item.is_confirmed)
  // } else if (filter === 'completed') {
  //   filteredTask = docList.filter((item) => item.is_confirmed)
  // }

  const filterHandler = (filter: FilterType) => {
    return () => setFilter(filter)
  }

  const total = docList.length
  // const done = docList.filter((item) => item.is_confirmed).length

  const taskListContent: EuiListGroupItemProps[] = useMemo(() => {
    return (docList || []).map((item, i) => {
      return {
        label: (
          <EuiText size="s" className="eui-textTruncate">
            {item.text}
          </EuiText>
        ),
        iconType: item.task_distributions[0].is_confirmed ? 'check' : 'questionInCircle',
        size: 's',
        onClick: () => setPageNumber(i),
      }
    })
  }, [docList, setPageNumber])
  return (
    <Fragment>
      <EuiFlexItem grow={false} style={{ flexShrink: 0 }}>
        {/* <EuiCollapsibleNavGroup
          title="Progress"
          iconType="training"
          isCollapsible={true}
          initialIsOpen={true}
          // onToggle={(isOpen) => toggleAccordion(isOpen, 'Progress')}
        >
          <EuiText size="s" style={{ padding: 4 }}>
            Total: {`${done}/${total}`}
          </EuiText>
          <EuiProgress
            value={Math.floor((done / total) * 100) || 0}
            max={100}
            color="secondary"
            size="m"
          />
        </EuiCollapsibleNavGroup> */}
      </EuiFlexItem>
      <EuiFlexItem className="eui-yScroll">
        {/* Docking button only for larger screens that can support it*/}
        <EuiCollapsibleNavGroup
          title={`Current: ${pageNumber + 1} of ${total}`}
          iconType="training"
          isCollapsible={true}
          initialIsOpen={true}
          // onToggle={(isOpen) => toggleAccordion(isOpen, 'DocList')}
        >
          <EuiFilterGroup fullWidth={true}>
            <EuiFilterButton
              withNext
              hasActiveFilters={filter === 'all'}
              onClick={filterHandler('all')}
            >
              All
            </EuiFilterButton>
            <EuiFilterButton
              withNext
              hasActiveFilters={filter === 'active'}
              onClick={filterHandler('active')}
            >
              Active
            </EuiFilterButton>
            <EuiFilterButton
              hasActiveFilters={filter === 'completed'}
              onClick={filterHandler('completed')}
            >
              Confirmed
            </EuiFilterButton>
          </EuiFilterGroup>
          <EuiSpacer size="s" />
          <EuiListGroup listItems={taskListContent} />
        </EuiCollapsibleNavGroup>
      </EuiFlexItem>
    </Fragment>
  )
}

export default CollapsibleNavAnnotator
