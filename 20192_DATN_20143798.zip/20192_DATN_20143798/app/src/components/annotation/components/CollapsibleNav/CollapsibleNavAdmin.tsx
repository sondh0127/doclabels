import React, { useMemo, Fragment } from 'react'
import { useRecoilValue, useRecoilState } from 'recoil'
import { docState, pageNumberState } from '@/contexts/atoms/annotation'
import { EuiListGroupItemProps, EuiText, EuiListGroup } from '@elastic/eui'

interface CollapsibleNavAdminProps {}

const CollapsibleNavAdmin: React.FC<CollapsibleNavAdminProps> = () => {
  const docList = useRecoilValue(docState)
  const [pageNumber, setPageNumber] = useRecoilState(pageNumberState)

  const docListContent: EuiListGroupItemProps[] = useMemo(() => {
    return (docList || []).map((item, i) => {
      return {
        label: (
          <EuiText size="s" className="eui-textTruncate">
            {item.text}
          </EuiText>
        ),
        // iconType: item.annotations_aggregate.aggregate?.count! > 0 ? 'check' : 'questionInCircle',
        // iconType: item.is_confirmed ? 'check' : 'questionInCircle',
        size: 's',
        onClick: () => setPageNumber(i),
      }
    })
  }, [docList])

  return (
    <Fragment>
      <EuiListGroup listItems={docListContent} />
    </Fragment>
  )
}

export default CollapsibleNavAdmin
