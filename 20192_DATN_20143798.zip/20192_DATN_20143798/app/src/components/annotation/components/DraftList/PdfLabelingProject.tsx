import { labelState, selectedAnnotationState } from '@/contexts/atoms/annotation'
import { useDraftAnno } from '@/hooks/useDraftAnno'
import { DraftAnnotation, Label } from '@/types'
import { EuiAccordion, EuiListGroup, EuiListGroupItem, EuiText } from '@elastic/eui'
import React, { Fragment, useMemo } from 'react'
import { useRecoilValue, useSetRecoilState } from 'recoil'

const PdfLabelingProject: React.FC = () => {
  const { presentAnno } = useDraftAnno()

  const annoByLabel = useMemo(() => {
    return presentAnno.reduce((result, currentValue) => {
      ;(result[currentValue.label_id] = result[currentValue.label_id] || []).push(currentValue)
      return result
    }, {} as Record<string, DraftAnnotation[]>)
  }, [presentAnno])
  const labelList = useRecoilValue(labelState)

  const labelMap = useMemo(
    () =>
      labelList.reduce((prev, curr) => {
        prev[curr.id] = curr
        return prev
      }, {} as Record<string, Label>),
    [labelList],
  )
  const setSelectedAnnotation = useSetRecoilState(selectedAnnotationState)

  const handleOnClick = (item: DraftAnnotation) => {
    setSelectedAnnotation(item)
  }

  return (
    <Fragment>
      {Object.entries(annoByLabel).length > 0 &&
        Object.entries(annoByLabel).map(([key, value]) => {
          return (
            <EuiAccordion
              key={key}
              id={`accordion-${key}`}
              arrowDisplay="right"
              buttonContent={<EuiText>{labelMap[key].text}</EuiText>}
              paddingSize="s"
              initialIsOpen={true}
            >
              <EuiListGroup flush={true} bordered={true}>
                {value.map((item) => {
                  if (item.data.type === 'PdfLabelingAnnotation') {
                    return (
                      <EuiListGroupItem
                        key={item.id}
                        onClick={() => handleOnClick(item)}
                        label={item.data.contents.text}
                      />
                    )
                  }
                  return null
                })}
              </EuiListGroup>
            </EuiAccordion>
          )
        })}
    </Fragment>
  )
}

export default PdfLabelingProject
