import { useApolloState } from '@/hooks/useAnnoState'
import { DraftSequenceLabelingAnnotation } from '@/types'
import { EuiAccordion, EuiText } from '@elastic/eui'
import React, { Fragment, useMemo } from 'react'
import { useDraftAnno } from '@/hooks/useDraftAnno'

const SequenceLabelingProject: React.FC = () => {
  const { presentAnno } = useDraftAnno()
  const { labelMap } = useApolloState()

  const annoByLabel = useMemo(() => {
    return presentAnno.reduce((result, currentValue) => {
      ;(result[currentValue.label_id] = result[currentValue.label_id] || []).push(currentValue)
      return result
    }, {} as Record<string, DraftSequenceLabelingAnnotation[]>)
  }, [presentAnno])

  return (
    <Fragment>
      {Object.entries(annoByLabel).length > 0 &&
        Object.entries(annoByLabel).map(([key, value]) => {
          return (
            <EuiAccordion
              key={key}
              id={`accordion-${key}`}
              arrowDisplay="right"
              buttonContent={key}
              paddingSize="s"
            >
              {value.map((item) => {
                return (
                  <EuiText key={item.id}>
                    <p>{item.data.tokens.join(' ')}</p>
                  </EuiText>
                )
              })}
            </EuiAccordion>
          )
        })}
    </Fragment>
  )
}

export default SequenceLabelingProject
