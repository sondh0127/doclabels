import { useApolloState } from '@/hooks/useAnnoState'
import { DraftSeq2seqAnnotation } from '@/types'
import { EuiAccordion, EuiText } from '@elastic/eui'
import React, { Fragment, useMemo } from 'react'
import { useDraftAnno } from '@/hooks/useDraftAnno'

const Seq2seqProject: React.FC = () => {
  const { presentAnno } = useDraftAnno()
  const { labelMap } = useApolloState()

  const annoByLabel = useMemo(() => {
    return (presentAnno || []).reduce((result, currentValue) => {
      ;(result[currentValue.label_id] = result[currentValue.label_id] || []).push(currentValue)
      return result
    }, {} as Record<string, DraftSeq2seqAnnotation[]>)
  }, [presentAnno])

  return (
    <Fragment>
      {Object.entries(annoByLabel).length > 0 &&
        Object.entries(annoByLabel).map(([key, value]) => {
          return (
            <EuiAccordion
              key={key}
              id={`accordion-${key}`}
              arrowDisplay="right"
              buttonContent={key}
              paddingSize="s"
            >
              {value.map((item) => {
                return (
                  <EuiText key={item.id}>
                    <p>{value.join(' ')}</p>
                  </EuiText>
                )
              })}
            </EuiAccordion>
          )
        })}
    </Fragment>
  )
}

export default Seq2seqProject
