import { useAnnoList, useApolloState, useCurrentDoc } from '@/hooks/useAnnoState'
import { selectedLabelState } from '@/contexts/atoms/annotation'
import { useDraftAnno } from '@/hooks/useDraftAnno'
import { DraftPdfLabelingAnnotation, Label } from '@/types'
import { getRandomUUID } from '@/utils/utils'
import { EuiButtonEmpty, EuiPopover } from '@elastic/eui'
// import Viewer, { Contents, PdfJs, RenderPageProps, Worker } from '@phuocng/react-pdf-viewer'
import React, { useCallback, useMemo, useRef, useState } from 'react'
import { useSetRecoilState } from 'recoil'
import AnnotationPopover from '../components/AnnotationPopover'
import Viewer, { Contents, PdfJs, RenderPageProps, Worker } from '@/components/pdf-annotation'
import AddAnnoModal from './AddAnnoModal'

const hexToRgb = (hex: string) => {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex)
  return result ? [parseInt(result[1], 16), parseInt(result[2], 16), parseInt(result[3], 16)] : []
}

const renderPage = (props: RenderPageProps) => {
  return (
    <>
      {props.canvasLayer.children}
      {props.textLayer.children}
      {props.annotationLayer.children}
    </>
  )
}

const PdfLabelingProject: React.FC = () => {
  const { labelList } = useApolloState()
  const currentDoc = useCurrentDoc()

  const setSelectedLabel = useSetRecoilState(selectedLabelState)
  const isDisabled = useMemo(() => false, [])

  // const addHighlight = (highlight: any, label: any) => {
  //   const payload = {
  //     ...highlight,
  //     label: label.id,
  //   }
  //   funcRef.current(payload)
  // }

  // const scrollViewerTo = React.useRef<any>(null)

  // const scrollToHighlightFromHash = () => {
  //   if (annoList) {
  //     const anno = annoList.find((val) => val.id === selectedAnno?.id)
  //     if (anno) scrollViewerTo.current(anno)
  //   }
  // }

  // useEffect(() => {
  //   if (selectedAnno && annoList) {
  //     scrollToHighlightFromHash()
  //   }
  // }, [selectedAnno])

  const [numPages, setNumPages] = useState(0)
  const [visible, setVisible] = useState(false)
  const [newAnno, setNewAnno] = useState<{
    position: PdfJs.Annotation
    contents: Contents
    pageNumber: number
  }>()

  const handleCancel = () => {
    setVisible(false)
    setNewAnno(undefined)
  }
  const hideTipAndSelectionRef = useRef<(() => void) | null>(null)

  const handleNewAnnotation = useCallback(
    (
      position: PdfJs.Annotation,
      contents: Contents,
      pageNumber: number,
      hideTipAndSelection: () => void,
    ) => {
      const { color, ...newPosition } = position
      setNewAnno({ position: { ...newPosition }, contents, pageNumber })
      setVisible(true)
      if (hideTipAndSelection) {
        hideTipAndSelectionRef.current = hideTipAndSelection
      }
    },
    [],
  )

  const { presentAnno, addAnno, removeAnno } = useDraftAnno()

  const handleConfirm = useCallback(
    (label: Label) => {
      if (newAnno) {
        const newDraftAnno: DraftPdfLabelingAnnotation = {
          id: getRandomUUID(),
          label_id: label.id,
          label: label,
          data: {
            ...newAnno,
            type: 'PdfLabelingAnnotation',
            label_text: label.text,
          },
        }
        addAnno(newDraftAnno)

        if (hideTipAndSelectionRef.current) {
          hideTipAndSelectionRef.current()
        }
        setSelectedLabel(label)
        setVisible(false)
      }
    },
    [newAnno],
  )

  const annotations = useMemo<PdfJs.Annotation[][]>(() => {
    if (numPages) {
      const annos = Array.from(Array(numPages), () => [] as PdfJs.Annotation[])
      if (presentAnno.length > 0) {
        ;(presentAnno as DraftPdfLabelingAnnotation[]).forEach((dAnnos) => {
          annos[dAnnos.data.pageNumber].push({
            ...dAnnos.data.position,
            id: dAnnos.data.position.id,
            color: new Uint8ClampedArray(hexToRgb(dAnnos.label?.color!)),
            label: dAnnos.label,
          })
        })
      }
      return annos
    }
    return []
  }, [presentAnno, numPages])

  const handleRemoveAnno = (annoId: string) => {
    const id = presentAnno.find(
      (item) => (item as DraftPdfLabelingAnnotation).data.position.id === annoId,
    )?.id
    if (id) {
      removeAnno(id)
    } else {
      console.log('error')
    }
  }

  if (currentDoc && currentDoc.text) {
    return (
      <Worker workerUrl="https://unpkg.com/pdfjs-dist@2.4.456/build/pdf.worker.min.js">
        <div className="content">
          <Viewer
            fileUrl={currentDoc.text}
            defaultScale={1.5}
            renderPage={renderPage}
            onDocumentLoad={(doc) => {
              setNumPages(doc.numPages)
            }}
            annotationValue={annotations}
            onNewAnnotation={handleNewAnnotation}
            SelectionPopover={({ content, onConfirm, style }) => {
              return (
                <EuiPopover
                  button={content}
                  isOpen={true}
                  closePopover={() => null}
                  anchorPosition="upCenter"
                  style={style}
                  panelPaddingSize="none"
                >
                  <EuiButtonEmpty size="s" onClick={onConfirm} iconType="listAdd">
                    Add annotation
                  </EuiButtonEmpty>
                </EuiPopover>
              )
            }}
            AnnotationPopover={({ content, onConfirm, data, style }) => {
              return (
                <AnnotationPopover
                  content={content}
                  onConfirm={onConfirm}
                  data={data}
                  style={style}
                  handleRemoveAnno={handleRemoveAnno}
                />
              )
            }}
          />
          <AddAnnoModal
            visible={visible}
            onConfirm={handleConfirm}
            onCancel={handleCancel}
            labelList={labelList}
          />
        </div>
        <style jsx>{`
          .content {
            position: relative;
            height: calc(100% + 48px);
            margin: -24px;
          }

          .content :global(.viewer-layout-container) {
            border: none;
          }
        `}</style>
      </Worker>
    )
  }

  return null
}

export default PdfLabelingProject
