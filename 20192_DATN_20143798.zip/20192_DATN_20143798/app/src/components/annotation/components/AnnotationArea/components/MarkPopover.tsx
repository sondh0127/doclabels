import { TokenSpan } from '@/hooks/useTextSelection'
import { EuiButtonIcon, EuiMark, EuiPopover, EuiText } from '@elastic/eui'
import React, { useState } from 'react'

interface MarkPopoverProps {
  token: TokenSpan
  onRemove: (id: string) => void
}

const MarkPopover: React.FC<MarkPopoverProps> = ({ token: { mark, content }, onRemove }) => {
  const [isPopoverOpen, setPopover] = useState(false)

  const onButtonClick = () => {
    setPopover(!isPopoverOpen)
  }

  const closePopover = () => {
    setPopover(false)
  }
  if (!mark) {
    return null
  }

  return (
    <EuiPopover
      key={`${mark.start_offset}-${mark.end_offset}`}
      button={
        <EuiMark
          style={{
            borderWidth: 1,
            borderRadius: 2,
            borderColor: mark.label.color,
            color: mark.label.color,
            backgroundColor: `${mark.label.color}16`,
            userSelect: 'none',
            margin: 2,
          }}
          data-start={mark.start_offset}
          data-end={mark.end_offset}
          onClick={onButtonClick}
        >
          {content}
        </EuiMark>
      }
      isOpen={isPopoverOpen}
      closePopover={closePopover}
      panelPaddingSize="none"
      withTitle
      ownFocus
      anchorPosition="upCenter"
    >
      <span style={{ display: 'flex', justifyContent: 'center' }}>
        <EuiText style={{ color: mark.label.color, marginRight: 2 }}>{mark.label.text}</EuiText>
        <EuiButtonIcon
          aria-label="Remove Mark"
          title="Remove"
          iconType="cross"
          onClick={() => onRemove(mark.id)}
          color="danger"
        />
      </span>
    </EuiPopover>
  )
}

export default MarkPopover
