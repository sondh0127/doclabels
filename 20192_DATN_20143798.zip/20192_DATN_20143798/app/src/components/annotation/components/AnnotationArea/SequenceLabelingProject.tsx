import { useApolloState, useCurrentDoc } from '@/hooks/useAnnoState'
import useTextSelection, {
  State,
  MarkedToken,
  splitTokensWithOffsets,
  TokenSpan,
} from '@/hooks/useTextSelection'
import { DraftSequenceLabelingAnnotation } from '@/types'
import { getRandomUUID, getContrastYIQ } from '@/utils/utils'
import { useUpdateEffect } from '@umijs/hooks'
import React, { useCallback, useMemo, Fragment, useState } from 'react'
import { useRecoilValue } from 'recoil'
import { selectedLabelState } from '@/contexts/atoms/annotation'
import { useDraftAnno } from '@/hooks/useDraftAnno'
import AnnoPagination from '../AnnoPagination'
import {
  EuiPanel,
  EuiIcon,
  EuiFlexGroup,
  EuiFlexItem,
  EuiSpacer,
  EuiMark,
  EuiCode,
  EuiText,
  EuiToolTip,
  EuiButtonIcon,
  EuiPopover,
  EuiContextMenu,
  EuiContextMenuPanel,
} from '@elastic/eui'
import MarkPopover from './components/MarkPopover'

const SequenceLabelingProject: React.FC = () => {
  const [selection, ref] = useTextSelection<HTMLDivElement>()
  const { presentAnno, addAnno, removeAnno } = useDraftAnno()

  const selectedLabel = useRecoilValue(selectedLabelState)

  const tokenValues: MarkedToken[] = useMemo(() => {
    return (presentAnno as DraftSequenceLabelingAnnotation[]).map((val) => ({
      ...val.data,
      id: val.id,
      label: val.label!,
    }))
  }, [presentAnno])

  const currentDoc = useCurrentDoc()

  const splits = useMemo<TokenSpan[]>(() => {
    const tokens = currentDoc ? currentDoc.text.split(' ') : []
    return splitTokensWithOffsets(tokens, tokenValues)
  }, [currentDoc, tokenValues])

  const handleAdd = useCallback(
    (newSelection: State) => {
      console.log(`SequenceLabelingProject:React.FC -> newSelection`, newSelection)
      // if (selectedLabel) {
      //   addAnno({
      //     id: getRandomUUID(),
      //     label: selectedLabel,
      //     label_id: selectedLabel.id,
      //     data: {
      //       type: 'SequenceLabelingAnnotation',
      //       start_offset: newSelection.start,
      //       end_offset: newSelection.end,
      //       tokens: newSelection.text.split(' '),
      //       label_text: selectedLabel.text,
      //     },
      //   })
      // }
    },
    [selectedLabel, addAnno],
  )

  useUpdateEffect(() => {
    if (selection.text) {
      handleAdd(selection)
    }
  }, [selection])

  const handleRemove = useCallback(
    (id: string) => {
      removeAnno(id)
    },
    [removeAnno],
  )

  // const handleEdit = useCallback(
  //   (id: string, label_id: string) => {
  //     // editAnnotation({ id, changes: { label_id } })
  //   },
  //   [editAnnotation],
  // )

  // {
  //   labelList &&
  //     labelList.map((item) => {
  //       if (item.id !== mark.label.id) {
  //         return (
  //           <Menu.Item key={item.id}>
  //             <Button
  //               block
  //               size="small"
  //               style={{
  //                 borderColor: item.color,
  //                 color: item.color,
  //               }}
  //             >
  //               {item.text}
  //             </Button>
  //           </Menu.Item>
  //         )
  //       }
  //       return null
  //     })
  // }

  return (
    <EuiFlexGroup direction="column" gutterSize="none">
      {currentDoc && (
        <EuiFlexItem>
          <EuiPanel
            style={{
              display: 'flex',
              minHeight: 128,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <div ref={ref} style={{ fontSize: 18 }}>
              {/* {splits.map((token) =>
                token.mark ? (
                  <MarkPopover token={token} onRemove={handleRemove} />
                ) : (
                  <div
                    style={{ display: 'inline-block', padding: 2 }}
                    key={token.i}
                    data-i={token.i}
                  >
                    {token.content}
                  </div>
                ),
              )} */}
              <EuiText id="container-rangy">
                {currentDoc.text.split('\n').map((item, key) => {
                  return <p key={key}>{item}</p>
                })}
              </EuiText>
            </div>
          </EuiPanel>
        </EuiFlexItem>
      )}
      <EuiSpacer size="s" />
      <AnnoPagination />
    </EuiFlexGroup>
  )
}
export default SequenceLabelingProject
