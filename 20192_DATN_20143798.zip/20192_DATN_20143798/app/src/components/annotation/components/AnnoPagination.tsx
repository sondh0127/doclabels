import { useApolloState } from '@/hooks/useAnnoState'
import { EuiFlexGroup, EuiFlexItem, EuiPagination, EuiPanel } from '@elastic/eui'
import React from 'react'
import { useRecoilState } from 'recoil'
import { pageNumberState } from '@/contexts/atoms/annotation'

const AnnoPagination: React.FC = React.memo(() => {
  const [pageNumber, setPageNumber] = useRecoilState(pageNumberState)
  const { totalDoc: total } = useApolloState()

  return (
    <EuiPanel>
      <EuiFlexGroup justifyContent="spaceAround">
        <EuiFlexItem grow={false}>
          <EuiPagination
            aria-label="Centered pagination example"
            pageCount={total}
            activePage={pageNumber}
            onPageClick={(activePage) => setPageNumber(activePage)}
          />
        </EuiFlexItem>
      </EuiFlexGroup>
    </EuiPanel>
  )
})

AnnoPagination.displayName = 'AnnoPagination'
AnnoPagination.whyDidYouRender = true

export default AnnoPagination
