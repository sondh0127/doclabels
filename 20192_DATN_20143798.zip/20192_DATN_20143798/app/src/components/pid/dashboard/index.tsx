import { currentProjectState } from '@/contexts/atoms/currentProject'
import { useProjectDashboardQuery } from '@/generated/graphql'
import {
  EuiLoadingSpinner,
  EuiPage,
  EuiPageBody,
  EuiPageContent,
  EuiPageContentBody,
  EuiSpacer,
  EuiPageHeader,
} from '@elastic/eui'
import { NextPage } from 'next'
import Head from 'next/head'
import Link from 'next/link'
import React, { useMemo } from 'react'
import { useRecoilValue } from 'recoil'
import styles from '@/components/projects/dashboard/dashboard.module.scss'
import DashboardHeader from '@/components/projects/dashboard/DashboardHeader'
import PublishedContent from '@/components/projects/dashboard/PublishedContent'
import UnPublishedContent from '@/components/projects/dashboard/UnPublishedContent'

const Dashboard: NextPage = () => {
  const currentProject = useRecoilValue(currentProjectState)

  const { data, loading } = useProjectDashboardQuery({
    variables: { project_id: currentProject?.id },
  })

  const percent = useMemo(() => {
    const total =
      data?.documents_aggregate.aggregate?.count! * currentProject?.annotator_per_example!
    const done = data?.documents_aggregate.nodes.filter(
      (n) => n.annotations_aggregate.aggregate?.count,
    ).length!

    return Math.min(Math.floor((done / total) * 100), 100)
  }, [data, currentProject])

  const showTaskAlert = useMemo(() => !data?.documents_aggregate.aggregate?.count, [data])

  const showLabelAlert = useMemo(() => !data?.labels_aggregate.aggregate?.count, [data])

  const statistics = useMemo<{
    contributors: number
    tasks: number
    labels: number
    visits: number
  }>(() => {
    return {
      contributors: data?.project_contributors_aggregate.aggregate?.count || 0,
      tasks: data?.documents_aggregate.aggregate?.count || 0,
      labels: data?.labels_aggregate.aggregate?.count || 0,
      visits: 0,
    }
  }, [data])

  const isPublishedDisabled = useMemo(() => !statistics.tasks || !statistics.labels, [statistics])

  return (
    <>
      {!currentProject && <EuiLoadingSpinner size="xl" />}
      {currentProject && (
        <>
          <Head>
            <title>Project Dashboard</title>
          </Head>
          <EuiPageBody>
            <EuiPageContent>
              <DashboardHeader currentProject={currentProject} statistics={statistics} />
            </EuiPageContent>
            <EuiPageContent className={styles.content}>
              {!currentProject.is_public && (
                <UnPublishedContent
                  statistics={statistics}
                  currentProject={currentProject}
                  showLabelAlert={showLabelAlert}
                  showTaskAlert={showTaskAlert}
                />
              )}
              {currentProject.is_public && (
                <PublishedContent
                  currentProject={currentProject}
                  data={data}
                  loading={loading}
                  percent={percent}
                />
              )}
            </EuiPageContent>
          </EuiPageBody>
        </>
      )}
    </>
  )
}

export default Dashboard
