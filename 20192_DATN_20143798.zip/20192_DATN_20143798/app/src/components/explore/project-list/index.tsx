import ProjectFieldSet, { Statistics } from '@/components/ProjectFieldSet'
import {
  Project_Types_Enum,
  useExploreProjectsQuery,
  ExploreProjectsQuery,
} from '@/generated/graphql'
import { useUser } from '@/hooks/useUser'
import produce from 'immer'
import { useRouter } from 'next/router'
import React, { useCallback, useEffect, useMemo, useState, Fragment } from 'react'
import {
  EuiLoadingSpinner,
  EuiFlexGrid,
  EuiButton,
  EuiText,
  EuiSpacer,
  EuiFlexGroup,
  EuiFlexItem,
} from '@elastic/eui'
import { useDebounce } from '@umijs/hooks'
import { Project } from '@/types'
import RequestForm from '../request-form'

interface CommonVariables {
  auth0_id: string
  limit: number
  offset: number
}

export interface ProjectsVariables {
  name_or_description: string
  project_types: Project_Types_Enum[]
}

interface MyProjectsProps {
  filterVariables: ProjectsVariables
  hasFilters: boolean
  removeFilters: () => void
}

const ProjectList: React.FC<MyProjectsProps> = ({ filterVariables, hasFilters, removeFilters }) => {
  const router = useRouter()
  const { user } = useUser()

  const commonVariables: CommonVariables = useMemo(
    () => ({
      auth0_id: user?.sub!,
      limit: 2,
      offset: 0,
    }),
    [user?.sub],
  )

  const debouncedValue = useDebounce(filterVariables, 500)
  const [selectedProject, setSelectedProject] = useState<Project>()

  const { data, loading, fetchMore, networkStatus } = useExploreProjectsQuery({
    variables: {
      ...commonVariables,
      ...debouncedValue,
    },
    notifyOnNetworkStatusChange: true,
  })

  const hasMore = useMemo(() => {
    return (
      networkStatus !== 3 &&
      data?.projects_aggregate.aggregate?.count !== data?.projects_aggregate.nodes.length
    )
  }, [
    data?.projects_aggregate?.aggregate?.count,
    data?.projects_aggregate?.nodes?.length,
    networkStatus,
  ])

  const onLoadMore = useCallback(() => {
    fetchMore({
      variables: {
        limit: 2,
        offset: data?.projects_aggregate.nodes.length,
      },
      updateQuery: (prev, { fetchMoreResult }) => {
        if (!fetchMoreResult) {
          return prev
        }

        const next = produce(prev, (draftState) => {
          draftState.projects_aggregate.nodes.push(...fetchMoreResult.projects_aggregate.nodes)
        })

        return next
      },
    })
  }, [data?.projects_aggregate?.nodes?.length, fetchMore])

  const renderData = useMemo<ExploreProjectsQuery['projects_aggregate']['nodes']>(() => {
    return data?.projects_aggregate.nodes || []
  }, [data?.projects_aggregate?.nodes])

  const getStatistics = useCallback((item: Project): Statistics => {
    return {
      contributors: 0,
      done: 0,
      tasks: 0,
    }
  }, [])

  return (
    <Fragment>
      <EuiFlexGroup direction="column" alignItems="center" justifyContent="center">
        {loading && <EuiLoadingSpinner size="xl" />}
        <EuiFlexItem>
          <EuiFlexGrid columns={2}>
            {!loading &&
              (renderData || []).map((item) => {
                const isSendRequest = item.project_notifications.length > 0
                const statistics = getStatistics(item)

                return (
                  <EuiFlexItem key={item.id}>
                    <ProjectFieldSet
                      statistics={{
                        contributors: 10,
                        done: 10,
                        tasks: 10,
                      }}
                      item={item}
                      extra={isSendRequest ? 'Requested' : 'Join'}
                      onClickExtra={
                        isSendRequest
                          ? () => {
                              return
                            }
                          : () => {
                              if (user) {
                                setSelectedProject(item)
                              } else {
                                router.replace(`/api/login`)
                              }
                            }
                      }
                    />
                  </EuiFlexItem>
                )
              })}
          </EuiFlexGrid>
        </EuiFlexItem>
        {hasMore && (
          <EuiButton onClick={onLoadMore} isLoading={networkStatus === 3}>
            Load more
          </EuiButton>
        )}
        {renderData && renderData.length === 0 && (
          <EuiFlexGroup alignItems="center" direction="column">
            <EuiFlexItem>
              <EuiText>No project</EuiText>
            </EuiFlexItem>
            <EuiFlexItem>
              {hasFilters && (
                <>
                  <EuiSpacer size="s" />
                  <EuiButton size="s" type="secondary" onClick={removeFilters}>
                    Remove filter
                  </EuiButton>
                </>
              )}
            </EuiFlexItem>
          </EuiFlexGroup>
        )}
      </EuiFlexGroup>
      {selectedProject && (
        <RequestForm
          project={selectedProject}
          onClose={() => setSelectedProject(undefined)}
          variables={{
            ...commonVariables,
            ...filterVariables,
          }}
        />
      )}
    </Fragment>
  )
}

export default ProjectList
