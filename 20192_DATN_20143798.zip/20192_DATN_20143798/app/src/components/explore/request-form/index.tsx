import { ROLE_LABELS } from '@/constants'
import {
  ExploreProjectsDocument,
  ExploreProjectsQuery,
  useContributorRequestMutation,
} from '@/generated/graphql'
import { useGlobalToasts } from '@/hooks/useGlobalToasts'
import { Project } from '@/types'
import {
  EuiButton,
  EuiButtonEmpty,
  EuiFormRow,
  EuiModal,
  EuiModalBody,
  EuiModalFooter,
  EuiModalHeader,
  EuiModalHeaderTitle,
  EuiOverlayMask,
  EuiSuperSelect,
} from '@elastic/eui'
import produce from 'immer'
import React, { Fragment, useState } from 'react'
import { Controller, useForm } from 'react-hook-form'
import { ProjectsVariables } from '../project-list'

interface FormValue {
  role: 'annotator' | 'annotation_approver'
}

interface RequestFormProps {
  project: Project
  onClose: () => void
  variables: ProjectsVariables & {
    auth0_id: string
    limit: number
    offset: number
  }
}

const RequestForm: React.FC<RequestFormProps> = ({ project, onClose, variables }) => {
  const { control, handleSubmit, errors, watch } = useForm<FormValue>({ mode: 'all' })

  const [request, { loading }] = useContributorRequestMutation()

  const { success, error } = useGlobalToasts()

  const [isModalVisible, setIsModalVisible] = useState(true)

  const closeModal = () => {
    setIsModalVisible(false)
    onClose()
  }

  const _onSubmit = async () => {
    const data = watch()
    try {
      await request({
        variables: {
          project_id: project.id,
          addition_data: { role_type: data.role },
        },
        update: (cache, { data }) => {
          if (data) {
            const getExisting = cache.readQuery<ExploreProjectsQuery>({
              query: ExploreProjectsDocument,
              variables: variables,
            })

            const next = produce(getExisting?.projects_aggregate, (draftState) => {
              if (draftState?.nodes) {
                const idx = draftState.nodes.findIndex((item) => item.id === project.id)
                draftState.nodes[idx].project_notifications.push(
                  data.insert_project_notifications_one!,
                )
              }
            })

            cache.writeQuery<ExploreProjectsQuery>({
              query: ExploreProjectsDocument,
              variables: variables,
              data: { projects_aggregate: next! },
            })
          }
        },
      })
      closeModal()
      success({ title: 'Request successfully!' })
    } catch (err) {
      error({ title: 'Something wrong.' })
      closeModal()
    }
  }

  let modal

  if (isModalVisible) {
    modal = (
      <EuiOverlayMask>
        <EuiModal onClose={closeModal} initialFocus="[name=popswitch]">
          <EuiModalHeader>
            <EuiModalHeaderTitle>Join Project</EuiModalHeaderTitle>
          </EuiModalHeader>

          <EuiModalBody>
            <EuiFormRow label="Role" isInvalid={Boolean(errors.role)} error={errors.role?.message}>
              <Controller
                control={control}
                name="role"
                rules={{
                  required: {
                    value: true,
                    message: 'Please choose a role',
                  },
                }}
                render={({ onChange, value, onBlur }) => (
                  <EuiSuperSelect
                    valueOfSelected={value}
                    isInvalid={Boolean(errors.role)}
                    onBlur={onBlur}
                    onChange={onChange}
                    placeholder="Select a role"
                    options={Object.entries(ROLE_LABELS).map(([key, value]) => ({
                      value: key,
                      inputDisplay: value,
                    }))}
                  />
                )}
              />
            </EuiFormRow>
          </EuiModalBody>

          <EuiModalFooter>
            <EuiButtonEmpty onClick={closeModal}>Cancel</EuiButtonEmpty>

            <EuiButton
              onClick={() => _onSubmit()}
              fill={false}
              isLoading={loading}
              disabled={loading || Object.keys(errors).length > 0}
            >
              Submit
            </EuiButton>
          </EuiModalFooter>
        </EuiModal>
      </EuiOverlayMask>
    )
  }
  return <Fragment>{modal}</Fragment>
}

export default React.memo(RequestForm)
