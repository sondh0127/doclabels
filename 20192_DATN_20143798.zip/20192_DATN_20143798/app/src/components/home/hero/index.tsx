import React from 'react'
import styles from './hero.module.scss'
import {
  EuiPage,
  EuiPageBody,
  EuiPageHeader,
  EuiPageHeaderSection,
  EuiTitle,
  EuiText,
  EuiButton,
  EuiLink,
  EuiFlexGroup,
  EuiFlexItem,
  EuiPageContent,
  EuiPageContentHeader,
  EuiPageContentHeaderSection,
  EuiSpacer,
  EuiTextColor,
} from '@elastic/eui'
import LogoIcon from '@/components/Icons/LogoIcon'
import { Parallax } from 'react-parallax'
import NextLink from 'next/link'
import { useRouter } from 'next/router'

interface HeroProps {}

const Hero: React.FC<HeroProps> = () => {
  const router = useRouter()
  return (
    <section className={styles.hero}>
      <EuiFlexGroup className={styles.heroPage} alignItems="center">
        <EuiFlexItem>
          <EuiFlexGroup gutterSize="xs" alignItems="center">
            <EuiFlexItem grow={false}>
              <LogoIcon height={32} width={32} ghost />
            </EuiFlexItem>
            <EuiFlexItem>
              <EuiText
                color="ghost"
                style={{ textTransform: 'uppercase', fontWeight: 700, letterSpacing: `2px` }}
              >
                DocLabels
              </EuiText>
            </EuiFlexItem>
          </EuiFlexGroup>
          <EuiSpacer />
          <EuiTitle size="l">
            <h2>
              <EuiTextColor color="ghost">Document annotation system</EuiTextColor>
            </h2>
          </EuiTitle>
          <EuiSpacer />
          <EuiText color="ghost">Decsription DecsriptionDecsriptionDecsriptionDecsription</EuiText>
          <EuiSpacer />
          <EuiButton
            onClick={() => router.push('/api/login')}
            fullWidth={false}
            iconType="arrowRight"
            iconSide="right"
            fill
            color="ghost"
          >
            Start now
          </EuiButton>
        </EuiFlexItem>
        <EuiFlexItem>
          <EuiTitle>
            <h1>Picture</h1>
          </EuiTitle>
        </EuiFlexItem>
      </EuiFlexGroup>
    </section>
  )
}

export default Hero
