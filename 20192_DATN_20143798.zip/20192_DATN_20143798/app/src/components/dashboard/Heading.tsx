import React, { useMemo } from 'react'
import Router from 'next/router'
import { useUser } from '@/hooks/useUser'
import {
  EuiFlexGroup,
  EuiPageContentHeaderSection,
  EuiPageContentHeader,
  EuiImage,
  EuiFlexItem,
  EuiText,
  EuiButton,
  EuiIcon,
  EuiLoadingContent,
} from '@elastic/eui'
import styles from './dashboard.module.scss'

interface HeadingProps {
  onButtonClick: () => void
}

const Heading: React.FC<HeadingProps> = ({ onButtonClick }) => {
  const { user, loading } = useUser()

  return (
    <EuiPageContentHeader>
      <EuiPageContentHeaderSection>
        {loading && <EuiLoadingContent lines={3} />}
        {user && (
          <EuiFlexGroup>
            <EuiFlexItem>
              <EuiImage size="s" alt="User picture" url={user.picture || ''} />
            </EuiFlexItem>
            <EuiFlexItem>
              <EuiText size="xs">
                <h2>{user.name}</h2>
              </EuiText>
              <EuiText className={styles.email}>
                <EuiIcon type="email" /> {user.email}
              </EuiText>
              <EuiText>Number of project</EuiText>
            </EuiFlexItem>
          </EuiFlexGroup>
        )}
      </EuiPageContentHeaderSection>
      <EuiPageContentHeaderSection>
        <EuiButton color="secondary" onClick={onButtonClick}>
          Create Project
        </EuiButton>
      </EuiPageContentHeaderSection>
    </EuiPageContentHeader>
  )
}

export default Heading
