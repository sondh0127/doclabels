import SwitchTheme from '@/components/layouts/switch_theme'
import { useApolloState } from '@/hooks/useAnnoState'
import HeaderUserMenu from '@/components/layouts/HeaderUserMenu'
import Logo from '@/components/layouts/logo'
import {
  EuiHeader,
  EuiHeaderSection,
  EuiHeaderSectionItem,
  EuiPage,
  EuiPageBody,
  EuiPageContent,
  EuiPageContentBody,
  EuiHeaderBreadcrumbs,
} from '@elastic/eui'
import { NextPage } from 'next'
import { useRouter } from 'next/router'
import React, { useMemo, useEffect } from 'react'
import { useRecoilValue } from 'recoil'
import styles from '@/components/annotation/annotation.module.scss'
// import FooterAnno from './components/Footer'
import SyncProjectRole from '@/components/annotation/SyncProjectRole'
import CollapsibleNav from '@/components/annotation/components/CollapsibleNav'
import FunctionNav from '@/components/annotation/components/FunctionNav'
import { useGlobalToasts, useToastsComponent } from '@/hooks/useGlobalToasts'
import { ProjectTypes } from '@/types'
import PdfLabelingProject from '@/components/annotation/components/AnnotationArea/PdfLabelingProject'
import Seq2seqProject from '@/components/annotation/components/AnnotationArea/Seq2seqProject'
import SequenceLabelingProject from '@/components/annotation/components/AnnotationArea/SequenceLabelingProject'
import TextClassificationProject from '@/components/annotation/components/AnnotationArea/TextClassificationProject'
import SyncApolloState from '@/components/annotation/SyncApolloState'
import { useUser } from '@/hooks/useUser'
import Head from 'next/head'
import { currentProjectState } from '@/contexts/atoms/annotation'
import { Project_Types_Enum } from '@/generated/graphql'

const AnnotationArea: Record<ProjectTypes, React.ElementType> = {
  PdfLabelingProject,
  Seq2seqProject,
  SequenceLabelingProject,
  TextClassificationProject,
}

const Annotation: NextPage = () => {
  const router = useRouter()
  const currentProject = useRecoilValue(currentProjectState)

  const { user, loading: userLoading } = useUser()

  useEffect(() => {
    if (!user && !userLoading) {
      router.push('/api/login')
    }
  }, [user, userLoading])

  const AnnotationAreaComponent = useMemo(() => {
    if (currentProject) {
      return AnnotationArea[currentProject.project_type]
    }
    return () => null
  }, [currentProject])

  const renderBreadcrumbs = () => {
    const breadcrumbs = [
      {
        text: 'Dashboard',
        href: '#',
        onClick: (e) => {
          router.push('/dashboard')
        },
        'data-test-subj': 'breadcrumbsAnimals',
        className: 'customClass',
      },
      {
        text: `${currentProject?.name}`,
        href: '#',
        onClick: (e) => {
          console.log('You clicked users')
        },
      },
      {
        text: `annotation`,
        href: '#',
        onClick: (e) => {
          console.log('You clicked annotation')
        },
      },
    ]

    return <EuiHeaderBreadcrumbs breadcrumbs={breadcrumbs} />
  }

  const ToastList = useToastsComponent()

  const contentStyle = useMemo(
    () =>
      currentProject?.project_type === Project_Types_Enum.PdfLabelingProject
        ? { height: `calc(100vh - 49px - 32px)` }
        : {},
    [currentProject],
  )

  return (
    <>
      <Head>
        <title>Annotation Editor</title>
      </Head>
      <SyncApolloState />
      <SyncProjectRole />
      <EuiHeader position="fixed">
        <EuiHeaderSection grow={false}>
          <EuiHeaderSectionItem border="right">
            <CollapsibleNav />

            <Logo onClick={() => router.push('/')} />
          </EuiHeaderSectionItem>
          <EuiHeaderSectionItem border="right">{/* <HeaderSpacesMenu /> */}</EuiHeaderSectionItem>
        </EuiHeaderSection>

        {renderBreadcrumbs()}

        <EuiHeaderSection side="right">
          <EuiHeaderSectionItem className={styles.switchTheme}>
            <SwitchTheme />
            <CollapsibleNav />
          </EuiHeaderSectionItem>
          {/* <EuiHeaderSectionItem>{renderSearch()}</EuiHeaderSectionItem> */}

          <EuiHeaderSectionItem>
            <HeaderUserMenu />
          </EuiHeaderSectionItem>
        </EuiHeaderSection>
      </EuiHeader>
      <EuiPage restrictWidth={1310}>
        <EuiPageBody component="div">
          <EuiPageContent style={contentStyle}>
            <AnnotationAreaComponent />
          </EuiPageContent>
        </EuiPageBody>
        <FunctionNav />
      </EuiPage>
      <ToastList />
    </>
  )
}

export default Annotation
