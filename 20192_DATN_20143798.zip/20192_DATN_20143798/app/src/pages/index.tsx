import React, { FunctionComponent } from 'react'
import {
  EuiButton,
  EuiCode,
  EuiPage,
  EuiPageBody,
  EuiPageContent,
  EuiPageContentBody,
  EuiPageContentHeader,
  EuiPageContentHeaderSection,
  EuiPageHeader,
  EuiPageHeaderSection,
  EuiText,
  EuiTitle,
  EuiIcon,
  EuiPanel,
} from '@elastic/eui'

import { EuiLink } from '@elastic/eui'
import MainLayout from '@/components/layouts/main_layout'

import AwesomeSlider from 'react-awesome-slider'

import GroupIcon from '@/components/Icons/GroupIcon'
import FormatIcon from '@/components/Icons/FormatIcon'
import TextIcon from '@/components/Icons/TextIcon'
import Hero from '@/components/home/hero'
import styles from '@/components/home/home.module.scss'

const bannerData = [
  {
    key: '#1',
    image: 'SentimentAnalysis',
    title: 'Sentiment Analysis',
    description: 'Sentiment Analysis',
  },
  {
    key: '#2',
    image: 'NamedEntityRecognition',
    title: 'Named Entity Recognition',
    description: 'Named Entity Recognition',
  },
  {
    key: '#3',
    image: 'Translation',
    title: 'Translation',
    description: 'Translation',
  },
  {
    key: '#4',
    image: 'PDFLabeling',
    title: 'PDF Labeling',
    description: 'PDF Labeling',
  },
]

const featureData = [
  {
    key: '#1',
    image: <GroupIcon />,
    title: 'Team Collaboration',
    description: 'Define guidelines and invite others to join your project',
  },
  {
    key: '#2',
    image: <TextIcon />,
    title: 'Text Annotation Tool',
    description: 'Variety in the type annotation tool',
  },
  {
    key: '#3',
    image: <FormatIcon />,
    title: 'Multiple formats',
    description: 'Annotation with team collaboration',
  },
]

const Index: FunctionComponent = () => (
  <MainLayout>
    <Hero />
    <EuiPage restrictWidth={1140}>
      <EuiPageBody>
        <EuiPageHeader>
          <EuiPageHeaderSection>
            <EuiTitle size="l">
              <h1>Doclabels</h1>
            </EuiTitle>
          </EuiPageHeaderSection>
          <EuiPageHeaderSection></EuiPageHeaderSection>
        </EuiPageHeader>

        <EuiPageContent>
          <EuiPageContentBody>
            {/* Feature Card */}
            <EuiText>GraphQL Tech Stack </EuiText>
            <EuiText>PDF Annotation</EuiText>
            <EuiText>Team Collaboration</EuiText>
            <EuiText>State Management System</EuiText>
            <EuiText>Tinh toan statistics</EuiText>
            <div className={`tw('text-center', 'p-16')`}>
              <EuiText>Features</EuiText>
              <div className={`tw('flex', 'items-center', 'justify-center')`}>
                {featureData.map((item) => (
                  <div key={item.key}>
                    <EuiPanel>
                      <div>{item.image}</div>
                      <div>{item.title}</div>
                      <div>{item.description}</div>
                    </EuiPanel>
                  </div>
                ))}
              </div>
            </div>
            {/* Banner */}
            {/* <AwesomeSlider className={`tw('h-96')`} bullets={false}>
              {bannerData.map((item) => (
                <div key={item.key}>
                  <div className={`tw('flex', 'items-center', 'justify-around', 'align-middle')`}>
                    <div>
                      <img alt="example" src={item.image} />
                    </div>
                    <div>
                      <div style={{ textAlign: 'left' }}>
                        <EuiText>{item.title}</EuiText>
                        <EuiText>{item.title}</EuiText>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </AwesomeSlider> */}
          </EuiPageContentBody>
        </EuiPageContent>
      </EuiPageBody>
    </EuiPage>
  </MainLayout>
)

export default Index
